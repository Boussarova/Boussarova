from flask import Flask, render_template, g

app = Flask(__name__)

navMenu = [
    {"link": "/index/", "name": "Главная"},
    {"link": "/info/", "name": "Биография"},
    {"link": "/two/", "name": "Лицей"},
    {"link": "/quatre/", "name": "Пушкин"},
    {"link": "/trois/", "name": "Портреты"}
 
]

@app.route("/index/")
@app.route("/")
def index():
    return render_template("index.html", menu=navMenu)

@app.route("/info/")
def info():
    return render_template("info.html", menu=navMenu)

@app.route("/two/")
def two():
    return render_template("two.html", menu=navMenu)

@app.route("/trois/")
def trois():
    return render_template("trois.html", menu=navMenu)

@app.route("/quatre/")
def quatre():
    return render_template("quatre.html", menu=navMenu)

if __name__ == "__main__":
    app.run()